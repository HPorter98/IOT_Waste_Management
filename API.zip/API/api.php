<?php 
    require "RestService.php";

    $service = new RestService();
    $service->HandleRequest();



?>