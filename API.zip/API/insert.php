<?php
    include 'dbInfo.php';
    $id = '';
    $long = '';
    $lat = '';
    $isFull = '';

    if (isset($_GET["id"])) {
        $id = $_GET["id"];
    }
    if (isset($_GET["long"])) {
        $long = $_GET["long"];
    }
    if (isset($_GET["lat"])) {
        $lat = $_GET["lat"];
    }
    if (isset($_GET["full"])) {
        $isFull = $_GET["full"];
    }

    function isEmpty($string){
        $s = trim($string);
        if(isset($s) == true && $s == '')
        {
        return true;
        }
        else{
            return false;
        }
    }   

    function printVars(){
        global $id, $long, $lat, $isFull;

        if (isEmpty($id)) {
            echo "<a> id not set </a><br>";
        }else{
            echo "<a>" . $id . "</a><br>";
        }

        if (isEmpty($long)) {
            echo "<a> long not set </a><br>";
        }else{
            echo "<a>" . $long . "</a><br>";
        }

        if (isEmpty($lat)) {
            echo "<a> lat not set </a><br>";
        }else{
            echo "<a>" . $lat . "</a><br>";
        }

        if (isEmpty($isFull)) {
            echo "<a> isFull not set </a><br>";
        }else{
            echo "<a>" . $isFull . "</a><br>";
        }
    }

    function InsertValues(){
        global $id, $long, $lat, $isFull;
        global $localHost, $username, $password, $table;

        if (isEmpty($id) == true && isEmpty($long) == true && isEmpty($lat) == true && isEmpty($isFull) == true) {
            echo "Data not provided";
        }
        else{
            
            $conn = mysqli_connect($localHost, $username, $password, $table);

            if (!$conn->connect_error) {
                $sql = "INSERT INTO bin_data (Latitude, Longitude, isFull) VALUES (?, ?, ?)";

                // Perpare SQL query
                $statement = $conn->prepare($sql);
                
                // Bind parameters to SQL query and execute
                $statement->bind_param('sss', $lat, $long, $isFull);
                $result = $statement->execute();

                if ($result == TRUE) {
                    echo "<a> Data added! </a><br>";
                }
                else{
                    echo "<a> Error! </a><br>";
                }
                $statement->close();
                $conn->close();
            }
            else{
                echo "<a> Can not connect to database </a><br>";
            }
        }
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Test Page</title>
</head>
<body>
    <?php printVars() ?>
    <?php InsertValues() ?>
</body>
</html>