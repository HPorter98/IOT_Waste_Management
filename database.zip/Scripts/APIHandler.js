var data;

function ClickMe(){
    $.ajax({
        url: "API/api.php",
        type: "GET",
        success: function (dataResult){
            var dataList = dataResult;
            CreateDataTable(dataList);
        }
    });
}

function CreateDataTable(dataList)
{
    data = JSON.parse(dataList);
    console.log(data.length);

    var html = "";

    html += "<tr><th>Bin ID</th><th>Latitude</th><th>Longitude</th><th>is Full</th></tr>";

    for(var i = 0; i <data.length; i++)
    {
        var id = data[i].BinId;
        var lat = data[i].Latitude;
        var long = data[i].Longitude;
        var is_Full = data[i].isFull;

        html += "<tr>";
        html += "<td>" + id + "</td>";
        html += "<td>" + lat + "</td>";
        html += "<td>" + long + "</td>";
        html += "<td>" + is_Full + "</td>";
        html += "</tr>";
    }
    document.getElementById("binTable").innerHTML = html;
}