<?php
    $localHost = "localhost";
    $username = "root";
    $password = "";
    $table = "dis_test";
?>