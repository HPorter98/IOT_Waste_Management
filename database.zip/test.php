

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="Scripts/jquery-1.10.2.min.js"></script>
    <script src="Scripts/APIHandler.js"></script>
    <link rel="stylesheet" href="style.css">
    <title>Test Page</title>
</head>
<body>
    <h1>Test Page</h1>
    <div class="container"> 
        <table id="mainTable">
            <tbody id="binTable"></tbody>
        </table>
        <button id= "btn1" onclick="ClickMe()">Display Data</button>
    </div>
</body>
</html>