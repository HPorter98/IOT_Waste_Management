CREATE TABLE bin_data (
  BinId int NOT NULL AUTO_INCREMENT,
  Latitude float,
  Longitude float,
  isFull varchar(5)
);

INSERT INTO bin_data (Latitude, Longitude, isFull) 
VALUES (110.605, 23.432, "True");

INSERT INTO bin_data (Latitude, Longitude, isFull) 
VALUES (120.432, 27.322, "True"); 

INSERT INTO bin_data (Latitude, Longitude, isFull) 
VALUES (68.125, 54.436, "False"); 